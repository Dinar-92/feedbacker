INSERT INTO users(login, password, roles)
VALUES ('admin',
        '523e4d700eee73c16f5cad5620af26a0:88c0475a69a8a2f9bb3de6011759dd383fae8104ba7e4338bde9e2cbeaeb281f',
        '{ROLE_ADMIN}');