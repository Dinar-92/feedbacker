CREATE TABLE users (
  id BIGSERIAL PRIMARY KEY,
  login TEXT NOT NULL UNIQUE,
  password TEXT NOT NULL,
  roles TEXT[] NOT NULL DEFAULT '{ROLE_USER}',
  avatar TEXT NOT NULL DEFAULT 'noavatar.svg',
  removed BOOLEAN NOT NULL DEFAULT FALSE,
  created TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE tokens (
    userId BIGINT NOT NULL REFERENCES users,
    token TEXT PRIMARY KEY
);

CREATE TABLE groups (
    id BIGSERIAL PRIMARY KEY,
    ownerId BIGINT NOT NULL REFERENCES users,
    name TEXT NOT NULL
);

CREATE TABLE memos (
    id BIGSERIAL PRIMARY KEY,
    authorId BIGINT NOT NULL REFERENCES users,
    groupId BIGINT NOT NULL REFERENCES groups,
    content TEXT,
    attachment TEXT
);

CREATE TABLE group_permissions(
    userId BIGINT NOT NULL REFERENCES users,
    groupId BIGINT NOT NULL REFERENCES groups,
    permissions INT NOT NULL DEFAULT 0
);