package tech.itpark.framework.crypto;

public interface TokenGenerator {
  String generate();
}
