package tech.itpark.framework.bodyconverter;

import lombok.RequiredArgsConstructor;
import tech.itpark.app.exception.ConversionException;

import java.io.Reader;
import java.io.StringWriter;
import java.io.Writer;

@RequiredArgsConstructor
public class StringBodyConverter implements BodyConverter {
  @Override
  public boolean canRead(String contentType, Class<?> clazz) {
    return clazz.isAssignableFrom(String.class);
  }

  @Override
  public boolean canWrite(String contentType, Class<?> clazz) {
    return clazz.isAssignableFrom(String.class);
  }

  @Override
  public <T> T read(Reader reader, Class<T> clazz) {
    try {
      final var writer = new StringWriter();
      reader.transferTo(writer);
      return (T) writer.toString();
    } catch (Exception e) {
      throw new ConversionException(e);
    }
  }

  @Override
  public void write(Writer writer, Object value) {
    try {
      writer.write((String) value);
    } catch (Exception e) {
      throw new ConversionException(e);
    }
  }
}
